﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;


public class PlayerController : NetworkBehaviour
{

	public float speed;
	public float jumpForce;
	private float moveInput;

	private Rigidbody2D rb;

	private bool facingRight = true;

	private bool isGrounded;
	public Transform groundCheck;
	public float checkRadius;
	public LayerMask whatIsGround;

	private int extraJumps;
	public int extraJumpsValue;

	public GameObject projectilePrefab;
	public Transform projectileSpawn;

	private static Random r = new Random(); //rawr xDDDD s0000 r4nD0m!!!!
	public Color col;

	// Use this for initialization
	void Start ()
	{
		extraJumps = extraJumpsValue;
		rb = GetComponent<Rigidbody2D> ();
	}

	void Update ()
	{

		if (!isLocalPlayer) {

			return;

		}

		if (Input.GetKeyDown (KeyCode.Space)) {
		
			CmdFire ();
		
		}
	
	}

	// Update is called once per frame
	void FixedUpdate ()
	{

		//MOVEMENT
		isGrounded = Physics2D.OverlapCircle (groundCheck.position, checkRadius, whatIsGround);
		moveInput = Input.GetAxis ("Horizontal");
		rb.velocity = new Vector2 (moveInput * speed, rb.velocity.y);

		//FLIPPING SPRITE
		if (facingRight == false && moveInput > 0) {
		
			Flip ();
		
		} else if (facingRight == true && moveInput < 0) {
		
			Flip ();
		
		}

		//JUMPING
		if (isGrounded == true) {
			extraJumps = extraJumpsValue;

		}

		if (Input.GetKeyDown (KeyCode.W) && extraJumps > 0) {
		
			rb.velocity = Vector2.up * jumpForce;
			extraJumps--;
			moveInput = Input.GetAxis ("Horizontal");
			rb.velocity = new Vector2 (moveInput * speed, rb.velocity.y);
		
		}

	}


	public override void OnStartLocalPlayer ()
	{
	
		//this function is a good place to do initialization that is only for the local player
		//such as configuring cameras and input

		//tell the local player apart from others for rn
		GetComponent<SpriteRenderer> ().color = Color.white;

	}


	void Flip ()
	{

		facingRight = !facingRight;
		Vector3 Scaler = transform.localScale;
		Scaler.x *= -1;
		transform.localScale = Scaler;

	}

	[Command]
	void CmdFire(){
	
		//create the projectile from the projectile prefab
		var projectile = (GameObject)Instantiate (
		
			                 projectilePrefab,
			                 projectileSpawn.position,
			                 projectileSpawn.rotation
		
		                 );

		//add velocity to the projectile
		if (facingRight == true) {
			col = new Color (Random.Range (.2F, 2F), Random.Range (.2F, 2F), Random.Range (.2F, 2F)); //RANDOM PROJECTILE COLOR UWU
			projectile.GetComponent<SpriteRenderer> ().color = col;

			projectile.GetComponent<Rigidbody2D> ().velocity = projectile.transform.right * 20;
		} 
		if (facingRight == false) {
			col = new Color (Random.Range (.2F, 2F), Random.Range (.2F, 2F), Random.Range (.2F, 2F)); //RANDOM PROJECTILE COLOR OWO
		projectile.GetComponent<Rigidbody2D> ().velocity = -projectile.transform.right * 20;

		}

		//spawn the projectiles on the clients
		NetworkServer.Spawn(projectile);

		//destroy the projectile after 2 seconds
		Destroy(projectile, 2.0f);
	}
	
	}

